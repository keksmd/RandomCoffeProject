package org.cofee.backendapp;

import org.cofee.backendapp.containers.TestcontainersConfiguration;
import org.springframework.boot.SpringApplication;

public class TestCofeeBackendAppApplication {

    public static void main(String[] args) {
        SpringApplication.from(CofeeBackendAppApplication::main).with(TestcontainersConfiguration.class).run(args);
    }

}
