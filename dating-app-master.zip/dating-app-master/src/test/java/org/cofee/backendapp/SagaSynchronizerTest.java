package org.cofee.backendapp;

import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.framework.template.service.RestMessagingService;
import org.cofee.backendapp.model.dto.UserDto;
import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.framework.synchronizer.SagaSynchronizer;
import org.cofee.backendapp.users.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mockito;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class SagaSynchronizerTest {
    @InjectMocks
    private SagaSynchronizer<UserDto> sagaSynchronizer;
    @InjectMocks
    private EntityService<UserDto> service1;
    @InjectMocks
    private RestMessagingService<UserDto> service2;

    @BeforeEach
    void setUp() {
        this.service1 = Mockito.mock(UserService.class);
        this.service2 = Mockito.mock(ModelRestMessagingServiceImpl.class);
        this.sagaSynchronizer = new SagaSynchronizer<UserDto>(service1, new ArrayList<>(List.of(service2)));
    }


    @Test
    void syncAddNice() {
        var id = UUID.randomUUID();
        var id2 = UUID.randomUUID();
        when(service1.add(Mockito.any())).thenReturn(id);
        when(service2.add(Mockito.any())).thenReturn(id2);
        assert id == sagaSynchronizer.syncAdd( UserDto.builder().age(18).name("alex").description("kek").build());

    }

    @Test
    void syncAddOriginalFailed() {
        var id = UUID.randomUUID();
        var id2 = UUID.randomUUID();
        when(service1.add(Mockito.any())).thenThrow(new OperationEndedWithoutSucces());
        when(service2.add(Mockito.any())).thenReturn(id2);
        assertThrows(OperationEndedWithoutSucces.class, () -> sagaSynchronizer.syncAdd( UserDto.builder().age(18).name("alex").description("kek").build()));
        verifyNoInteractions(service2);

    }

    @Test
    void syncAddDependedFailed() {
        var id = UUID.randomUUID();
        var id2 = UUID.randomUUID();
        when(service2.add(Mockito.any())).thenThrow(new OperationEndedWithoutSucces());
        when(service1.add(Mockito.any())).thenReturn(id);
        assertThrows(OperationEndedWithoutSucces.class, () -> sagaSynchronizer.syncAdd( UserDto.builder().age(18).name("alex").description("kek").build()));
        verify(service1).delete(id);

    }

    @Test
    void syncDelete() {
    }

    @Test
    void syncUpdate() {
    }
}