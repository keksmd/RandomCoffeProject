package org.cofee.backendapp.framework.template.model.dto;

import org.cofee.backendapp.model.dto.PlaceDto;
import org.cofee.backendapp.model.dto.UserDto;
import org.junit.jupiter.api.Test;

class DtoFabricTest {
    private final DtoFabric<UserDto> fabricUser = new DtoFabric<>(UserDto.class);
    private final DtoFabric<PlaceDto> fabricPlace = new DtoFabric<>(PlaceDto.class);

    @Test
    void getZero() {
        assert UserDto.builder().build().equals(fabricUser.getZero());
        assert PlaceDto.builder().build().equals(fabricPlace.getZero());
    }
}