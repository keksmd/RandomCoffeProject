package org.cofee.backendapp.containers;

import org.cofee.backendapp.model.entity.AddressEntity;
import org.cofee.backendapp.model.entity.PlaceEntity;
import org.cofee.backendapp.places.PlaceRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.junit.jupiter.Testcontainers;

import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
@SpringBootTest(classes = TestcontainersConfiguration.class)
@Testcontainers
@AutoConfigureMockMvc
class TestcontainersConfigurationTest {

    @Autowired
    private MockMvc mockmvc;
    @Autowired
    private PlaceRepository placeRepository;
    @Test
    void whenSaveUser_thenUserIsSaved() throws Exception {
        PlaceEntity placeEntity = new PlaceEntity(UUID.randomUUID(),"test",new AddressEntity("test","test",1));
        PlaceEntity saved = placeRepository.save(placeEntity);
        assertThat(saved.getId()).isNotNull();

    }
    //@Test
    void endpoints() throws Exception {
        this.mockmvc.perform(get("/api/v1/places/1")
                .accept(MediaType.APPLICATION_JSON))
                .andExpectAll(
                        status().is2xxSuccessful(),
                        content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON));

        this.mockmvc.perform(post("/api/v1/places")
                        .accept(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                    "name": "test",
                                    "adressDto: {
                                        "city": "test",
                                        "street": "test",
                                        "house": 1
                                    }
                                }
                                """))
                .andExpectAll(
                        status().is2xxSuccessful());
    }

}