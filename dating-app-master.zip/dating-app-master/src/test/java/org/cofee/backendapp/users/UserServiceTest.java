package org.cofee.backendapp.users;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class UserServiceTest {

    @Test
    void delete() {
    }

    @Test
    void add() {
    }

    @Test
    void update() {
    }

    @Test
    void get() {
    }
}