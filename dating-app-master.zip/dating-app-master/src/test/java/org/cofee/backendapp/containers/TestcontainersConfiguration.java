package org.cofee.backendapp.containers;

import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.testcontainers.containers.PostgreSQLContainer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ch.qos.logback.classic.Level;

@TestConfiguration
public class TestcontainersConfiguration {
    @Bean
    @ServiceConnection
    public PostgreSQLContainer<?> postgreSQLContainer(DynamicPropertyRegistry registry) {
        var container = new PostgreSQLContainer("postgres:13.4");
        registry.add("postgresql. driver", container::getDriverClassName);
        Logger logger = LoggerFactory.getLogger("org.testcontainers");
        ((ch.qos.logback.classic.Logger) logger).setLevel(Level.DEBUG);
        return container;
    }
}
