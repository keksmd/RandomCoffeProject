package org.cofee.backendapp.ex;

public class OperationEndedWithoutSucces extends RuntimeException{
    public OperationEndedWithoutSucces() {
    }

    public OperationEndedWithoutSucces(String message) {
        super(message);
    }

    public OperationEndedWithoutSucces(String message, Throwable cause) {
        super(message, cause);
    }

    public OperationEndedWithoutSucces(Throwable cause) {
        super(cause);
    }

    public OperationEndedWithoutSucces(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
