package org.cofee.backendapp.messages;

public enum MessageStatus {
    SENDED,
    DELIVERED,
    READED;
}
