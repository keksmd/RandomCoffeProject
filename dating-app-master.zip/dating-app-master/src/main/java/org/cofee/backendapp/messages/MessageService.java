package org.cofee.backendapp.messages;


import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.model.dto.MessageDto;
import org.cofee.backendapp.model.entity.MessageEntity;
import org.cofee.backendapp.users.UserRepository;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.UUID;

@Service

public class MessageService {
    final private MessageRepository messageRepository;
    private final UserRepository userRepository;


    public MessageService(MessageRepository messageRepository, UserRepository userRepository) {
        this.messageRepository = messageRepository;
        this.userRepository = userRepository;
    }
    public boolean delete(UUID id){
        try{
            messageRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    public UUID add(MessageDto messageDto){
        return messageRepository.save(map(new MessageEntity(),messageDto)).getId();
    };

    public UUID update(MessageDto messageDto, UUID id){

        MessageEntity entity = map(messageRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден")),messageDto);

        return messageRepository.save(entity).getId();
    };
    public MessageDto get(UUID id) throws OperationEndedWithoutSucces {
        MessageEntity entity = messageRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден"));
       return map(entity);
    };
    private MessageEntity map(MessageEntity entity,MessageDto messageDto){
        entity.setTo(userRepository.findById(messageDto.getUserToId()).orElseThrow(OperationEndedWithoutSucces::new));
        entity.setFrom(userRepository.findById(messageDto.getUserFromId()).orElseThrow(OperationEndedWithoutSucces::new));
        entity.setId(messageDto.getId()==null?UUID.randomUUID():messageDto.getId());
        entity.setBody(messageDto.getBody());
        entity.setStatus(messageDto.getStatus());
        entity.setCreated_at(Timestamp.valueOf(messageDto.getCreatedAt()));

        return entity;

    }
    public  MessageDto map(MessageEntity entity){
        return MessageDto.builder()
                .userFromId(entity.getFrom().getId())
                .status(entity.getStatus())
                .userToId(entity.getTo().getId())
                .createdAt(entity.getCreated_at().toLocalDateTime())
                .body(entity.getBody())
                .createdAt(entity.getCreated_at().toLocalDateTime())
                .id(entity.getId())
                .build();
    }

}
