package org.cofee.backendapp.addresses;


import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.model.dto.AddressDto;
import org.cofee.backendapp.model.entity.AddressEntity;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service

public class AddressService implements EntityService<AddressDto> {
    final private AddressRepository addressRepository;


    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }
    public boolean delete(UUID id){
        try{
            addressRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    };

    public UUID add(AddressDto addressDto){
        AddressEntity addressEntity = new AddressEntity();
        addressEntity.setCity(addressDto.getCity());
        addressEntity.setHouse(addressDto.getHouse());
        addressEntity.setStreet(addressDto.getStreet());
        addressEntity.setId(addressDto.getId()==null?UUID.randomUUID():addressDto.getId());
        return addressRepository.save(addressEntity).getId();

    };

    public UUID update(AddressDto addressDto, UUID id){

        AddressEntity addressEntity = addressRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден"));
        addressEntity.setCity(addressDto.getCity());
        addressEntity.setHouse(addressDto.getHouse());
        addressEntity.setStreet(addressDto.getStreet());
        return addressRepository.save(addressEntity).getId();
    };
    public AddressDto get(UUID id) throws OperationEndedWithoutSucces {
        AddressEntity entity = addressRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден"));
       return AddressDto
               .builder()
               .city(entity.getCity())
               .house(entity.getHouse())
               .street(entity.getStreet())
               .build();

    };

}
