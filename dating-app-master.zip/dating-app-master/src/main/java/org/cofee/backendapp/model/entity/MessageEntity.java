package org.cofee.backendapp.model.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.cofee.backendapp.messages.MessageStatus;

import java.sql.Timestamp;
import java.util.UUID;

@NoArgsConstructor
@Entity
@Data
public class MessageEntity {
    @Id
    private UUID id;
    @ManyToOne
    private UserEntity from;
    @ManyToOne
    private UserEntity to;
    private String body;
    @Enumerated(EnumType.ORDINAL)
    private MessageStatus status;
    private Timestamp created_at;

}
