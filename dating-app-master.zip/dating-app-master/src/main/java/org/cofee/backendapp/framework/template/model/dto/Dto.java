package org.cofee.backendapp.framework.template.model.dto;


import lombok.Data;
import lombok.experimental.SuperBuilder;

@SuperBuilder
@Data

public class Dto {
}
