package org.cofee.backendapp.framework.synchronizer;

import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.framework.template.service.RestMessagingService;
import org.cofee.backendapp.ex.OperationEndedWithoutSucces;

import java.util.LinkedList;
import java.util.List;
import java.util.UUID;



public class SagaSynchronizer<T> implements Synchronizer<T> {
    private final EntityService<T> originalService;
    private final List<RestMessagingService<T>> serviceToSynchronize;

    public SagaSynchronizer(EntityService<T> originalService, List<RestMessagingService<T>> serviceToSynchronize) {
        this.originalService = originalService;
        this.serviceToSynchronize = serviceToSynchronize;
    }

    @Override
    public UUID syncAdd(T userDto) throws OperationEndedWithoutSucces {
       try{
           UUID[] ids = new UUID[serviceToSynchronize.size() + 1];
           ids[0] = this.originalService.add(userDto);
           int num = 1;
           while (num<ids.length && serviceToSynchronize.iterator().hasNext()) {
               try {
                   ids[num]= serviceToSynchronize.iterator().next().add(userDto);
                   num++;
               } catch (OperationEndedWithoutSucces e) {
                   for (int i = 0; i < num; i++) {
                       serviceToSynchronize.get(i).delete(ids[i]);
                       originalService.delete(ids[0]);
                   }
                   throw new OperationEndedWithoutSucces(String.format("Service %s's add operation failed", serviceToSynchronize.get(0).toString()));
               }
           }
               return ids[0];

       }catch (OperationEndedWithoutSucces e){
         throw new OperationEndedWithoutSucces("Сага закончилась безуспешно");
       }
    }
    @Override
    @Deprecated
    public UUID syncDelete(UUID id) throws OperationEndedWithoutSucces {
        try{
            LinkedList<T > ids = new LinkedList<T>();
            ids.add(originalService.get(id));
            originalService.delete(id);
            int num = 1;
            while (serviceToSynchronize.iterator().hasNext()) {
                try {
                    var service = serviceToSynchronize.iterator().next();
                    ids.add(service.get(id));
                    service.delete(id);
                    num++;
                } catch (OperationEndedWithoutSucces e) {
                    for (int i = num-1; i >=0; i--) {
                        serviceToSynchronize.get(i).add(ids.poll());
                    }
                    originalService.add(ids.poll());
                    throw new OperationEndedWithoutSucces(String.format("Service %s's add operation failed", serviceToSynchronize.get(0).toString()));
                }
            }
            return id;

        }catch (OperationEndedWithoutSucces e){
            throw new OperationEndedWithoutSucces("Сага закончилась безуспешно,основной сервис не смог удалить объект");
        }
    }
    @Override
    @Deprecated
    public UUID syncUpdate(UUID id, T dto) throws OperationEndedWithoutSucces {
        try{
            LinkedList<T > old = new LinkedList<T>();
            old.add(originalService.get(id));
            originalService.update(dto,id);
            int num = 1;
            while (serviceToSynchronize.iterator().hasNext()) {
                try {
                    var service = serviceToSynchronize.iterator().next();
                    old.add(service.get(id));
                    service.delete(id);
                    num++;
                } catch (OperationEndedWithoutSucces e) {
                    for (int i = num-1; i >=0; i--) {
                        serviceToSynchronize.get(i).add(old.poll());
                    }
                    throw new OperationEndedWithoutSucces(String.format("Service %s's add operation failed", serviceToSynchronize.get(0).toString()));
                }
            }
            return id;

        }catch (OperationEndedWithoutSucces e){
            throw new OperationEndedWithoutSucces("Сага закончилась безуспешно,основной сервис не смог удалить объект");
        }
    }
}
