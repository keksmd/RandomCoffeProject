package org.cofee.backendapp.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;
import org.cofee.backendapp.framework.template.model.dto.Dto;

import java.util.Objects;
import java.util.UUID;

@EqualsAndHashCode(callSuper = false)
@Data
@SuperBuilder
public final class PlaceDto extends Dto {


    private UUID id;
    @JsonProperty
    private String name;
    @JsonProperty("address_id")
    private UUID address;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof PlaceDto placeDto)) return false;
        if (!super.equals(o)) return false;
        return Objects.equals(id, placeDto.id) && Objects.equals(name, placeDto.name) && Objects.equals(address, placeDto.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), id, name, address);
    }
}
