package org.cofee.backendapp.model.entity;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.UUID;
@EqualsAndHashCode
@Entity
@Data
@AllArgsConstructor

public class UserEntity {
    @Id
    private UUID id;
    private String name;
    private int age;
    private String description;
    @ManyToOne
    private AddressEntity address;
    public UserEntity() {
        this.id = UUID.randomUUID();
    }
}
