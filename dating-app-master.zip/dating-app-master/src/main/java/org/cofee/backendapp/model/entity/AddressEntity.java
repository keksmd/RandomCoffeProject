package org.cofee.backendapp.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Entity
@Data
@NoArgsConstructor
@EqualsAndHashCode


public class AddressEntity {
    public AddressEntity(String city, String street, int house) {
        this.city = city;
        this.street = street;
        this.house = house;
        this.id = UUID.randomUUID();
    }

    @Id
    private UUID id;
    private String city;
    private String street;
    private int house;
}
