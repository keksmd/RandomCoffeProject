package org.cofee.backendapp.framework.template.service;

import org.cofee.backendapp.ex.OperationEndedWithoutSucces;

import java.util.UUID;

public interface EntityService<Dto> {
    boolean delete(UUID id) throws OperationEndedWithoutSucces;

    UUID  add(Dto userDto) throws OperationEndedWithoutSucces;

    UUID update(Dto userDto,UUID id) throws OperationEndedWithoutSucces;

    Dto get(UUID id) throws OperationEndedWithoutSucces;
}
