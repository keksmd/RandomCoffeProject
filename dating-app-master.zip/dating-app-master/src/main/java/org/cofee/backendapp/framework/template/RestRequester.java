package org.cofee.backendapp.framework.template;
import org.cofee.backendapp.framework.template.model.dto.Dto;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.UUID;


public class RestRequester<T extends Dto> {
    private final String urlContext;
    private final RestTemplate restTemplate;
    private final Class<T> responseType;
    private final String resourceName;

    public RestRequester(String resourceName,String urlContext,Class<T> dtoClass) {
        this.resourceName = resourceName;
        this.restTemplate = new RestTemplate();
        this.urlContext = urlContext;
        this.responseType = dtoClass;
    }
    public ResponseEntity<Boolean> delete(UUID id){
        return restTemplate.exchange(urlContext+resourceName+"/{id}", HttpMethod.DELETE,null,Boolean.class,id);
    }
    public ResponseEntity<UUID>  add(T dto){
        return restTemplate.exchange(urlContext+resourceName+"/", HttpMethod.POST,new HttpEntity<>(dto), UUID.class);
    }
    public boolean isReachable(){

        var response = restTemplate.exchange(urlContext+"status/",HttpMethod.GET,null, Boolean.class);
        if(response.getStatusCode().is2xxSuccessful()&&response.hasBody()){
            return Boolean.TRUE.equals(response.getBody());
        }else{
            return false;
        }
    }
    public ResponseEntity<UUID> update(T dto, UUID id){
        return restTemplate.exchange(urlContext+resourceName+"/{id}", HttpMethod.POST,new HttpEntity<>(dto), UUID.class,id);
    }
    public ResponseEntity<T> get(UUID id){
        return restTemplate.exchange(urlContext+resourceName+"/{id}", HttpMethod.GET,null, responseType,id);
    }
}
