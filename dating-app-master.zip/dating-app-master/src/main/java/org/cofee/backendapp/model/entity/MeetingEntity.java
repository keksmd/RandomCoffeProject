package org.cofee.backendapp.model.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Timestamp;
import java.util.List;
import java.util.UUID;

@NoArgsConstructor
@Entity
@Data
public class MeetingEntity {
    @Id
    private UUID id;
    @ManyToMany
    @JoinTable()
    private List<UserEntity> members;
    private Timestamp meetingDate;
    @ManyToOne
    private PlaceEntity place;


}
