package org.cofee.backendapp.framework.template.model.dto;

public class DtoFabric<Dto1 extends Dto> extends AbstractDtoFabric<Dto1>{
    public DtoFabric(Class<Dto1> responceType1){
        super();
        this.responceType = responceType1;
    }
    private final Class<Dto1> responceType;
    @Override
    public Dto1 getZero() {
        return super.createEmptyByReflection(responceType);
    }
}
