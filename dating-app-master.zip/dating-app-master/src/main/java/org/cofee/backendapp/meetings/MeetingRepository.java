package org.cofee.backendapp.meetings;

import org.cofee.backendapp.model.entity.MeetingEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.UUID;

public interface MeetingRepository extends CrudRepository<MeetingEntity, UUID> {
}
