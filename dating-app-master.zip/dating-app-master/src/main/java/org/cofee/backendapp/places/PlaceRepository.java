package org.cofee.backendapp.places;

import org.cofee.backendapp.model.entity.PlaceEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.UUID;

public interface PlaceRepository extends CrudRepository<PlaceEntity, UUID> {
}
