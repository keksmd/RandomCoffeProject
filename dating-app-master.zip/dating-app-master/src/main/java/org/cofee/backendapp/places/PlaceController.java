package org.cofee.backendapp.places;

import org.cofee.backendapp.model.dto.PlaceDto;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/places/")
public class PlaceController {
    private final org.cofee.backendapp.places.PlaceService placeService;




    public PlaceController(PlaceService placeService) {
        this.placeService = placeService;
    }

    @PostMapping
    public ResponseEntity<UUID> add(@RequestBody PlaceDto placeDto){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(placeService.add(placeDto));
    }
    @GetMapping({"/{id}"})
    public ResponseEntity<PlaceDto> get(@PathVariable UUID id){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(placeService.get(id));
    }
    @PostMapping({"/{id}"})
    public ResponseEntity<UUID> update(@PathVariable UUID id,@RequestBody PlaceDto placeDto){
      return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(placeService.update(placeDto,id));
    }
    @DeleteMapping({"/{id}"})
    public ResponseEntity<Boolean> delete(@PathVariable UUID id){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(placeService.delete(id));
    }



}
