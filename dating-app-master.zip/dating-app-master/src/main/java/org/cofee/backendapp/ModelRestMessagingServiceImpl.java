package org.cofee.backendapp;

import org.cofee.backendapp.framework.template.service.AbstractRestMessagingService;
import org.cofee.backendapp.model.dto.UserDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
@Service
public class ModelRestMessagingServiceImpl extends AbstractRestMessagingService<UserDto> {

    public ModelRestMessagingServiceImpl(@Value("{model.context}")String urlContext, @Value("users.resource")String resourceName) {
       super(urlContext,resourceName,UserDto.class);
    }


}
