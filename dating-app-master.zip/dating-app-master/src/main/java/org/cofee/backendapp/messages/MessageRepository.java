package org.cofee.backendapp.messages;

import org.cofee.backendapp.model.entity.MessageEntity;
import org.springframework.data.repository.CrudRepository;

import java.util.UUID;

public interface MessageRepository extends CrudRepository<MessageEntity, UUID> {
}
