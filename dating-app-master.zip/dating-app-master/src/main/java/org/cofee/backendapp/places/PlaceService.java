package org.cofee.backendapp.places;


import org.cofee.backendapp.addresses.AddressRepository;
import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.ex.ResourceNotFoundException;
import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.model.dto.PlaceDto;
import org.cofee.backendapp.model.entity.AddressEntity;
import org.cofee.backendapp.model.entity.PlaceEntity;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service

public class PlaceService implements EntityService<PlaceDto> {
    final private PlaceRepository placeRepository;
    private final AddressRepository addressRepository;


    public PlaceService(PlaceRepository placeRepository, AddressRepository addressRepository) {
        this.placeRepository = placeRepository;
        this.addressRepository = addressRepository;
    }
    public boolean delete(UUID id){
        try{
            placeRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    };

    public UUID add(PlaceDto placeDto){
        PlaceEntity entity = new PlaceEntity();
        entity.setName(placeDto.getName());
        entity.setId(placeDto.getId()==null?UUID.randomUUID():placeDto.getId());
        entity.setAddress(addressRepository.findById(placeDto.getAddress()).orElseThrow(()->new ResourceNotFoundException(AddressEntity.class,placeDto.getAddress())));
        return placeRepository.save(entity).getId();

    };

    public UUID update(PlaceDto placeDto, UUID id){

        PlaceEntity entity = placeRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(PlaceEntity.class,placeDto.getId()));
        entity.setName(placeDto.getName());
        entity.setAddress(addressRepository.findById(placeDto.getAddress()).orElseThrow(()->new ResourceNotFoundException(AddressEntity.class,placeDto.getAddress())));
        return placeRepository.save(entity).getId();
    };
    public PlaceDto get(UUID id) throws OperationEndedWithoutSucces {
        PlaceEntity entity = placeRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден"));
       return PlaceDto.builder()
               .name(entity.getName())
               .address(entity.getAddress().getId())
               .build();
    };

}
