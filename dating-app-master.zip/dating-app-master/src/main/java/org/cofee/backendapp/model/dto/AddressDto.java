package org.cofee.backendapp.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.Objects;
import java.util.UUID;

@Data
@Builder

public final class AddressDto {
    @JsonProperty
    private UUID id;

    @JsonProperty

    private String city;
    @JsonProperty
    private String street;
    @JsonProperty
    private int house;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AddressDto that)) return false;
        return house == that.house && Objects.equals(city, that.city) && Objects.equals(street, that.street);
    }

    @Override
    public int hashCode() {
        return Objects.hash(city, street, house);
    }
}
