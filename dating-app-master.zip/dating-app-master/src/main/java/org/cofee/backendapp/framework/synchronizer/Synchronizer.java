package org.cofee.backendapp.framework.synchronizer;

import org.cofee.backendapp.ex.OperationEndedWithoutSucces;

import java.util.UUID;

public interface Synchronizer<T> {
    UUID syncAdd(T dto) throws OperationEndedWithoutSucces;

    @Deprecated
    UUID syncDelete(UUID id) throws OperationEndedWithoutSucces;

    @Deprecated
    UUID syncUpdate(UUID id, T dto) throws OperationEndedWithoutSucces;
}
