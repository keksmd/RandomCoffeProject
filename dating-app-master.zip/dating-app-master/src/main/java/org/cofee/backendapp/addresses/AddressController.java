package org.cofee.backendapp.addresses;

import org.cofee.backendapp.model.dto.AddressDto;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/addresss/")
public class AddressController {
    private final AddressService addressService;
    public AddressController(AddressService addressService) {
        this.addressService = addressService;
    }

    @PostMapping
    public ResponseEntity<UUID> add(@RequestBody AddressDto addressDto){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(addressService.add(addressDto));
    }
    @GetMapping({"/{id}"})
    public ResponseEntity<AddressDto> get(@PathVariable UUID id){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(addressService.get(id));
    }
    @PostMapping({"/{id}"})
    public ResponseEntity<UUID> update(@PathVariable UUID id,@RequestBody AddressDto addressDto){
      return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(addressService.update(addressDto,id));
    }
    @DeleteMapping({"/{id}"})
    public ResponseEntity<Boolean> delete(@PathVariable UUID id){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(addressService.delete(id));
    }



}
