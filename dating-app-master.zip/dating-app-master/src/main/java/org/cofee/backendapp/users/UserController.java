package org.cofee.backendapp.users;

import org.cofee.backendapp.model.dto.UserDto;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/users/")
public class UserController {
    private final org.cofee.backendapp.users.UserService userService;


    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping
    public ResponseEntity<UUID>add(@RequestBody UserDto userDto){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(userService.add(userDto));
    }



    @GetMapping({"/{id}"})
    public ResponseEntity<UserDto> get(@PathVariable UUID id){

        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(userService.get(id));
    }
    @PostMapping({"/{id}"})
    public  ResponseEntity<UUID> update(@PathVariable UUID id,@RequestBody UserDto userDto){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(userService.update(userDto,id));
    }
    @DeleteMapping({"/{id}"})
    public  ResponseEntity<Boolean> delete(@PathVariable UUID id){
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(userService.delete(id));
    }



}
