package org.cofee.backendapp.framework.template.service;

import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.framework.template.RestRequester;
import org.cofee.backendapp.framework.template.model.dto.AbstractDtoFabric;
import org.cofee.backendapp.framework.template.model.dto.Dto;
import org.cofee.backendapp.framework.template.model.dto.DtoFabric;

import java.util.Objects;
import java.util.UUID;

public abstract class AbstractRestMessagingService<Dto1 extends Dto>  implements RestMessagingService<Dto1> {
    private final RestRequester<Dto1> restRequester;
    private final AbstractDtoFabric<Dto1> dtoFabric;

    protected AbstractRestMessagingService(String urlContext,String resourceName,Class<Dto1> dtoClass) {
        this.restRequester = new RestRequester<Dto1>(resourceName,urlContext,dtoClass);
        this.dtoFabric = new DtoFabric<Dto1>(dtoClass);
    }


    @Override
    public boolean delete(UUID id) {
        try {
            var response = restRequester.delete(id);
            if (response.getStatusCode().is2xxSuccessful()){
                return Objects.requireNonNullElse(response.getBody(), Boolean.FALSE);
            }else{
                return false;
            }
        }catch (Exception e ){
            return false;
        }
    }
    @Override
    public UUID  add(Dto1 dto1) throws OperationEndedWithoutSucces {
        try {
            var response = restRequester.add(dto1);
            if (response.getStatusCode().is2xxSuccessful()){
                UUID ans = response.getBody();
                if(ans!=null){
                    return ans;
                }else{
                    throw new OperationEndedWithoutSucces("не удалось добавить объект в  сервис");
                }
            }else{
                throw new OperationEndedWithoutSucces("не удалось добавить объект в  сервис");
            }
        }catch (Exception e ){
            throw new OperationEndedWithoutSucces("не удалось добавить объект в  сервис");
        }
    }
    @Override
    public UUID update(Dto1 dto1, UUID id) throws OperationEndedWithoutSucces {
        try {
            var response = restRequester.update(dto1,id);
            if (response.getStatusCode().is2xxSuccessful()){
                UUID ans = response.getBody();
                if(ans!=null){
                    return ans;
                }else{
                    throw new OperationEndedWithoutSucces("не удалось обновитьт объект в  сервис");
                }
            }else{
                throw new OperationEndedWithoutSucces("не удалось  обновить объект в  сервис");
            }
        }catch (Exception e ){
            throw new OperationEndedWithoutSucces("не удалось обновить объект в  сервис");
        }
    }
    @Override
    public Dto1 get(UUID id) {
        try {
            var response = restRequester.get(id);
            if (response.getStatusCode().is2xxSuccessful()){
                return Objects.requireNonNullElse(response.getBody(), dtoFabric.getZero());
            }else{
                return dtoFabric.getZero();
            }

        }catch (Exception e ){
            return dtoFabric.getZero();
        }
    }

    @Override
    public boolean isReachable() {
        return restRequester.isReachable();
    }
}
