package org.cofee.backendapp.framework.template.service;

public interface RestMessagingService<T> extends EntityService<T> {
    boolean isReachable();

}
