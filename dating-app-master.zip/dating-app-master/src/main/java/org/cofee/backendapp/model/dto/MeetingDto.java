package org.cofee.backendapp.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Data
@Builder
public class MeetingDto {
    @JsonProperty
    UUID place;
    @JsonProperty
    private UUID id;
    @JsonProperty
    private List<UUID> members;
    @JsonProperty
    private LocalDateTime meetingDate;

}
