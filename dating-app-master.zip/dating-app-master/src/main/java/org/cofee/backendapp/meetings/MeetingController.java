package org.cofee.backendapp.meetings;

import org.cofee.backendapp.model.dto.MeetingDto;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/meetings/")
public class MeetingController {
    private final MeetingService meetingService;


    public MeetingController(MeetingService meetingService) {
        this.meetingService = meetingService;
    }

    @PostMapping
    public ResponseEntity<UUID> add(@RequestBody MeetingDto meetingDto) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(meetingService.add(meetingDto));
    }

    @GetMapping({"/{id}"})
    public ResponseEntity<MeetingDto> get(@PathVariable UUID id) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(meetingService.get(id));
    }

    @PostMapping({"/{id}"})
    public ResponseEntity<UUID> update(@PathVariable UUID id, @RequestBody MeetingDto meetingDto) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(meetingService.update(meetingDto, id));
    }

    @DeleteMapping({"/{id}"})
    public ResponseEntity<Boolean> delete(@PathVariable UUID id) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(meetingService.delete(id));
    }


}
