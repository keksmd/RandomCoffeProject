package org.cofee.backendapp.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.experimental.SuperBuilder;
import org.cofee.backendapp.framework.template.model.dto.Dto;

import java.util.Objects;
import java.util.UUID;

@Data
@SuperBuilder

public final class UserDto extends Dto {

    @JsonProperty
    private UUID id;
    @JsonProperty("address_id")
    private UUID address;
    @JsonProperty
    private  String name;
    @JsonProperty
    private int age;
    @JsonProperty
    private String description;
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserDto userDto)) return false;
        return age == userDto.age && Objects.equals(name, userDto.name) && Objects.equals(description, userDto.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, age, description);
    }



}
