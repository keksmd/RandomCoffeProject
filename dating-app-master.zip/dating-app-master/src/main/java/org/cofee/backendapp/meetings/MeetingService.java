package org.cofee.backendapp.meetings;


import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.model.dto.MeetingDto;
import org.cofee.backendapp.model.entity.MeetingEntity;
import org.cofee.backendapp.model.entity.UserEntity;
import org.cofee.backendapp.places.PlaceRepository;
import org.cofee.backendapp.users.UserRepository;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.UUID;

@Service

public class MeetingService implements EntityService<MeetingDto> {
    final private MeetingRepository meetingRepository;
    final private PlaceRepository placeRepository;
    private final UserRepository userRepository;


    public MeetingService(MeetingRepository meetingRepository, PlaceRepository placeRepository, UserRepository userRepository) {
        this.meetingRepository = meetingRepository;
        this.placeRepository = placeRepository;
        this.userRepository = userRepository;
    }
    public boolean delete(UUID id){
        try{
            meetingRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    }

    public UUID add(MeetingDto meetingDto){
        return meetingRepository.save(map(new MeetingEntity(),meetingDto)).getId();
    };

    public UUID update(MeetingDto meetingDto, UUID id){

        MeetingEntity entity = map(meetingRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден")),meetingDto);

        return meetingRepository.save(entity).getId();
    };
    public MeetingDto get(UUID id) throws OperationEndedWithoutSucces {
        MeetingEntity entity = meetingRepository.findById(id).orElseThrow(()->new OperationEndedWithoutSucces("объект не найден"));
       return map(entity);
    };
    private MeetingEntity map(MeetingEntity entity,MeetingDto meetingDto){
        entity.setMeetingDate(Timestamp.valueOf(meetingDto.getMeetingDate()));
        entity.setMembers(meetingDto.getMembers().stream().map(userRepository::findById).map(
                        opt-> opt.orElseThrow(OperationEndedWithoutSucces::new))
                .toList());
        entity.setPlace(placeRepository.findById(meetingDto.getPlace()).orElseThrow(OperationEndedWithoutSucces::new));
        entity.setId(meetingDto.getId()==null?UUID.randomUUID():meetingDto.getId());
        return entity;

    }
    public  MeetingDto map(MeetingEntity entity){
        return MeetingDto.builder()
                .members(entity.getMembers().stream().map(UserEntity::getId).toList())
                .meetingDate(entity.getMeetingDate().toLocalDateTime())
                .place(entity.getPlace().getId())
                .build();
    }

}
