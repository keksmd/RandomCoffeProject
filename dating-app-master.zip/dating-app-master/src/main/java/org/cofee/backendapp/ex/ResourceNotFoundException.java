package org.cofee.backendapp.ex;

public class ResourceNotFoundException extends OperationEndedWithoutSucces {
    public ResourceNotFoundException(Class<?> resourceClazz,Object id) {
        super("resource "+resourceClazz.getName()+"not found by id: "+id);
    }
}