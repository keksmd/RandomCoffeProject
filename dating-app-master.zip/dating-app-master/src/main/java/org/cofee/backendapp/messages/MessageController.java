package org.cofee.backendapp.messages;

import org.cofee.backendapp.model.dto.MessageDto;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("api/v1/messages/")
public class MessageController {
    private final MessageService messageService;


    public MessageController(MessageService messageService) {
        this.messageService = messageService;
    }

    @PostMapping
    public ResponseEntity<UUID> add(@RequestBody MessageDto messageDto) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(messageService.add(messageDto));
    }

    @GetMapping({"/{id}"})
    public ResponseEntity<MessageDto> get(@PathVariable UUID id) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(messageService.get(id));
    }

    @PostMapping({"/{id}"})
    public ResponseEntity<UUID> update(@PathVariable UUID id, @RequestBody MessageDto messageDto) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(messageService.update(messageDto, id));
    }

    @DeleteMapping({"/{id}"})
    public ResponseEntity<Boolean> delete(@PathVariable UUID id) {
        return ResponseEntity.ok().contentType(MediaType.APPLICATION_JSON).body(messageService.delete(id));
    }


}
