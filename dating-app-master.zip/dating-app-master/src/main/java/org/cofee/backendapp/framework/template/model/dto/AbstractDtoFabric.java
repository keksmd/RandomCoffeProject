package org.cofee.backendapp.framework.template.model.dto;

import org.cofee.backendapp.framework.ex.FrameworkException;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Optional;

public abstract class AbstractDtoFabric<T extends Dto> {
    T createEmptyByBuilder(T.DtoBuilder<?, ?> builder) {
        return (T) builder.build();
    }
    public abstract T getZero();
    T createEmptyByReflection(Class<T> clazz) {


        Optional<Method> optionalBuiler = Arrays.stream(clazz.getMethods()).filter(method -> method.getName().equals("builder")).findFirst();
        var builder = optionalBuiler.orElseThrow(() -> new FrameworkException(String.format("Not found method. builder in class %s", clazz.descriptorString())));
        builder.setAccessible(true);

        Class<?> builderClass = null;
        try {
            builderClass = (Class<?>) builder.invoke(null).getClass();

            Optional<Method> optionalBuid = Arrays.stream(builderClass.getMethods()).filter(method -> method.getName().equals("build")).findFirst();
            Class<?> finalBuilderClass = builderClass;
            var build = optionalBuid.orElseThrow(() -> new FrameworkException(String.format("Not found method build in class %s", finalBuilderClass.descriptorString())));
            build.setAccessible(true);

            return (T) build.invoke(builder.invoke(null));


        } catch (IllegalAccessException | InvocationTargetException e) {
            throw new RuntimeException(e);
        }

    }

}
