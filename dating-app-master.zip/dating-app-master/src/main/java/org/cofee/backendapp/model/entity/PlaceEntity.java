package org.cofee.backendapp.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.UUID;

@NoArgsConstructor
@EqualsAndHashCode
@AllArgsConstructor
@Data
@Entity
public class PlaceEntity {
    @Id
    private UUID id;
    private String name;
    @ManyToOne
    private AddressEntity address;

}
