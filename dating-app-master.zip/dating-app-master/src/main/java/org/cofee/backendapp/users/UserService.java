package org.cofee.backendapp.users;


import org.cofee.backendapp.ex.ResourceNotFoundException;
import org.cofee.backendapp.addresses.AddressRepository;
import org.cofee.backendapp.ex.OperationEndedWithoutSucces;
import org.cofee.backendapp.framework.template.service.EntityService;
import org.cofee.backendapp.model.dto.UserDto;
import org.cofee.backendapp.model.entity.AddressEntity;
import org.cofee.backendapp.model.entity.UserEntity;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service

public class UserService implements EntityService<UserDto> {
    final private UserRepository userRepository;
    private final AddressRepository addressRepository;


    public UserService(UserRepository userRepository, AddressRepository addressRepository) {
        this.userRepository = userRepository;
        this.addressRepository = addressRepository;
    }
    public boolean delete(UUID id){
        try{
            userRepository.deleteById(id);
            return true;
        }catch (Exception e){
            return false;
        }
    };

    public UUID add(UserDto userDto){
        UserEntity entity = new UserEntity();
        entity.setName(userDto.getName());
        entity.setDescription(userDto.getDescription());
        entity.setAge(userDto.getAge());
        entity.setId(userDto.getId()==null?UUID.randomUUID():userDto.getId());
        entity.setAddress(addressRepository.findById(userDto.getAddress()).orElseThrow(()->new ResourceNotFoundException(AddressEntity.class,userDto.getAddress())));
        return userRepository.save(entity).getId();

    };
    public UserDto findById(UUID id) throws OperationEndedWithoutSucces {
        UserEntity entity =userRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(UserEntity.class,id));
        return UserDto.builder().name(entity.getName()).description(entity.getDescription()).age(entity.getAge()).address(entity.getAddress().getId()).build();
    }

    public UUID update(UserDto userDto, UUID id){
        UserEntity entity =userRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(UserEntity.class,id));
        entity.setName(userDto.getName());
        entity.setDescription(userDto.getDescription());
        entity.setAge(userDto.getAge());
        entity.setAddress(addressRepository.findById(userDto.getAddress()).orElseThrow(()->new ResourceNotFoundException(AddressEntity.class,userDto.getAddress())));
        return userRepository.save(entity).getId();
    };

    public UserDto get(UUID id) throws OperationEndedWithoutSucces {
        UserEntity entity =userRepository.findById(id).orElseThrow(()->new ResourceNotFoundException(UserEntity.class,id));
       return UserDto.builder().name(entity.getName()).description(entity.getDescription()).age(entity.getAge()).build();
    };

}
